<link href="{{asset('backEndResource/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('backEndResource/font-awesome/css/font-awesome.css')}}" rel="stylesheet">

<!-- Toastr style -->
<link href="{{asset('backEndResource/css/plugins/toastr/toastr.min.css')}}" rel="stylesheet">

<!-- Gritter -->
<link href="{{asset('backEndResource/css/plugins/dataTables/datatables.min.css')}}" rel="stylesheet">
<link href="{{asset('backEndResource/js/plugins/gritter/jquery.gritter.css')}}" rel="stylesheet">

<link href="{{asset('backEndResource/css/plugins/jasny/jasny-bootstrap.min.css')}}" rel="stylesheet">

<link href="{{asset('backEndResource/css/plugins/select2/select2.min.css')}}" rel="stylesheet" >



<!-- jQuery/jQueryUI (hosted) -->
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.24/themes/ui-lightness/jquery-ui.css" rel="stylesheet">


<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.css" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('FrontEndPageResource/rating/rating.css') }}"
<link href="{{asset('backEndResource/css/animate.css')}}" rel="stylesheet">
<link href="{{asset('backEndResource/css/style.css')}}" rel="stylesheet">




