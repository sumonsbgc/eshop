@extends('backEnd.templateParts.master')
@section('title', 'Reports')
@section('content')
    
@endsection