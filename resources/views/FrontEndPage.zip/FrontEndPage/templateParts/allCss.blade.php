<link href="{{asset('FrontEndPageResource/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.8.1/css/all.css">
<link rel="stylesheet" href="{{asset('FrontEndPageResource/font/icofont.min.css')}}">
<link href="{{asset('FrontEndPageResource/owlCarousel/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('FrontEndPageResource/owlCarousel/owl.theme.default.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="{{asset('FrontEndPageResource/jquery.exzoom.css')}}" rel="stylesheet">
<link href="{{asset('lang_assets/css/flags.css')}}" rel="stylesheet">
<!--data-table css-->
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

<link href="{{asset('FrontEndPageResource/style.css')}}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('FrontEndPageResource/rating/rating.css') }}">
<link rel="stylesheet" href="{{ asset('FrontEndPageResource/responsivemenu/slicknav.min.css') }}">