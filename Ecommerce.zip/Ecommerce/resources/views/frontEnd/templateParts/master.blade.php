<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>@yield('title')</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    @csrf
    @include('frontEnd.templateParts.allCss')
</head>

<body>

@include('frontEnd.templateParts.header')

@yield('content')



{{--@include('frontEnd.templateParts.brands')--}}



@include('frontEnd.templateParts.subscribe')
@include('frontEnd.templateParts.footer')
@include('frontEnd.templateParts.allScript')

</body>



</html>