<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="{{asset('frontEndResource/assets/images/favicon.ico')}}">

<!-- CSS
============================================ -->

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/bootstrap.min.css')}}">

<!-- Icon Font CSS -->
<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/icon-font.min.css')}}">



{{--<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/icofont.min.css')}}">--}}

<!-- Plugins CSS -->
<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/plugins.css')}}">



<!-- Main Style CSS -->
<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/myAccountStyle.css')}}">


<link rel="stylesheet" href="{{asset('frontEndResource/assets/css/style.css')}}">

<!-- Modernizer JS -->
<script src="{{asset('frontEndResource/assets/js/vendor/modernizr-2.8.3.min.js')}}"></script>

{{--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">--}}