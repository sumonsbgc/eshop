<div class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 justify-content-center align-self-center text-left py-2">
                <div class="site-logo">
                    <img src="{{asset('FrontEndPageResource/image/Ecommerce-Logo-Vector.png')}}" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <div class="search-option">
                    <div class="form">
                        <form action="" method="">
                            <div class="form-group">
                                <input type="text" class="form-control" name="search-product" placeholder="Search Here....">
                                <button type="submit">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 text-right py-2">
                <div class="cart-and-auth">
                    <div class="shopping-cart">
                        <div class="cart">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="badge badge-secondary">0</span>
                        </div>
                    </div>
                    <div class="login-register">
                        <a href="" class="sign-in">Sign In</a>
                        <a href="" class="sign-up">Sign Up</a>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <!-- Navbar -->
                <div class="mega-menu">
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Contact</a></li>
                        <li class="sub-item">
                            <a class="has-sub" href="">Abc</a>
                            <div class="sub-menu">
                                <ul>
                                    <li>
                                        <a href="">Sub Menu</a>
                                        <ul class="has-child">
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li>
                                        <a href="">Sub Menu</a>
                                    </li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a></li>
                                    <li><a href="">Sub Menu</a>

                                        <ul class="has-child">
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                            <li><a href="">Sub menu item</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li><a href="{{url('category')}}">Category Page</a></li>
                        <li><a href="{{url('single')}}">Single Page</a></li>
                        <li><a href="">Form</a></li>
                        <li><a href="">Form</a></li>
                        <li><a href="">Form</a></li>
                        <li><a href="">Form</a></li>
                    </ul>
                </div>
                <!-- Navbar -->
            </div>
        </div>
    </div>
</div>