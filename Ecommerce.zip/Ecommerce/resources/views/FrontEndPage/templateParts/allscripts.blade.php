<script src="{{asset('FrontEndPageResource/bootstrap/js/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('FrontEndPageResource/bootstrap/js/popper.min.js')}}"></script>
<script src="{{asset('FrontEndPageResource/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('FrontEndPageResource/owlCarousel/owl.carousel.min.js')}}"></script>
<script src="http://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="{{asset('FrontEndPageResource/mixitup.min.js')}}"></script>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="{{asset('FrontEndPageResource/jquery.exzoom.js')}}"></script>