<link href="{{asset('FrontEndPageResource/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
<link rel="stylesheet" href="{{asset('FrontEndPageResource/font/icofont.min.css')}}">
<link href="{{asset('FrontEndPageResource/owlCarousel/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('FrontEndPageResource/owlCarousel/owl.theme.default.min.css')}}" rel="stylesheet">
<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="{{asset('FrontEndPageResource/jquery.exzoom.css')}}" rel="stylesheet">

<link href="{{asset('FrontEndPageResource/style.css')}}" rel="stylesheet">