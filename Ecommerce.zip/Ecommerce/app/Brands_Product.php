<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Brands_Product extends Model
{
    protected $table='brands__products';

    protected $guarded = [];
}
