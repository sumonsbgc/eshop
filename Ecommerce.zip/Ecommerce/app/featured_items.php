<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class featured_items extends Model
{
    protected $table='featured_items';

    protected $guarded =[];
}
