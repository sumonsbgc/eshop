<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BestDeal extends Model
{
    protected $table='best_deals';

    protected $guarded=[];
}
