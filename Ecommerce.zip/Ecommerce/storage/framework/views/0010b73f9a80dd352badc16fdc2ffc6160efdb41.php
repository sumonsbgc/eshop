<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontEndResource/assets/images/favicon.ico')); ?>">

<!-- CSS
============================================ -->

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontEndResource/assets/css/bootstrap.min.css')); ?>">

<!-- Icon Font CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontEndResource/assets/css/icon-font.min.css')); ?>">





<!-- Plugins CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontEndResource/assets/css/plugins.css')); ?>">



<!-- Main Style CSS -->
<link rel="stylesheet" href="<?php echo e(asset('frontEndResource/assets/css/myAccountStyle.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('frontEndResource/assets/css/style.css')); ?>">

<!-- Modernizer JS -->
<script src="<?php echo e(asset('frontEndResource/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

