<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageAdvertisement extends Model
{

    protected $table = 'page_advertisements';

    protected $guarded = [];

}
