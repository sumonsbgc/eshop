<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slider_image extends Model
{
    protected $table = 'slider_image';

    protected $guarded=[];
}
