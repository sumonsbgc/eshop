<?php
use App\Category;
use App\Post;
if(!function_exists('getCategoryName')){
  function getCategoryName($cat){
    return Category::find($cat)->name;
  }
}

if(!function_exists('getAllPostCategories')){
  function getAllPostCategories(){
    return Category::where(['post_type' => 'post'])->get();
  }
}


if(!function_exists('getAllTrashPosts')){
  function getAllTrashPosts(){
    return Post::onlyTrashed(['post_type' => 'post'])->get();
  }
}


if (!function_exists('get_customer_order')){
    function get_customer_order($time,$user_id){

        $products =\Illuminate\Support\Facades\DB::table('orders')
            ->join('products','orders.product_id','=','products.id')
            ->where('orders.created_at','=',$time)
            ->where('orders.user_id','=',$user_id)
            ->select('orders.*','products.product_name','products.product_price')
            ->get();

        return $products;
    }
}

if (!function_exists('get_category_name')){
    function get_category_name($cat_id){
        $cat = Category::where('id',$cat_id)->first();

        return $cat;
    }
}

