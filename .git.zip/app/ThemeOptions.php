<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThemeOptions extends Model
{
    protected $guarded = [];
}
