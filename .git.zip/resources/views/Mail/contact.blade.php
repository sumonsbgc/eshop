


<table border="1" cell-spacing="0" cell-padding="8" width="100%">
    <tbody>
        <tr>
            <td>Name</td>
            <td>{{ $name }}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td>{{ $email }}</td>
        </tr>
        <tr>
            <td>Mobile</td>
            <td>{{ $mobile }}</td>
        </tr>
        <tr>
            <td>Message</td>
            <td>{{ $user_message }}</td>
        </tr>
    </tbody>
</table>
