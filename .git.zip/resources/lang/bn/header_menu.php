<?php

return [
    'categories' => 'Sokol Categories'
];